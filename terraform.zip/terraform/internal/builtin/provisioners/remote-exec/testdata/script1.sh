cd /tmp
wget http://foobar
exit 0
