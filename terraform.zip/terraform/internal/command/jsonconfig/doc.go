// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: BUSL-1.1

// Package jsonconfig implements methods for outputting a configuration snapshot
// in machine-readable json format
package jsonconfig
