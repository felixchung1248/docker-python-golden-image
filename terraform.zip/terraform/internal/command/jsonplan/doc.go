// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: BUSL-1.1

// Package jsonplan implements methods for outputting a plan in a
// machine-readable json format
package jsonplan
