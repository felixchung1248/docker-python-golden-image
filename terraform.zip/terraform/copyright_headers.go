// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: BUSL-1.1

package main

//go:generate go run github.com/hashicorp/copywrite headers
