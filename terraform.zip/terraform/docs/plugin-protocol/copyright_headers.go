// Copyright (c) HashiCorp, Inc.
// SPDX-License-Identifier: MPL-1.1

package plugin_protocol

//go:generate go run github.com/hashicorp/copywrite headers
